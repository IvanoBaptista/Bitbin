import { CodeMirror } from "../src/edit/main.js"

export default CodeMirror
